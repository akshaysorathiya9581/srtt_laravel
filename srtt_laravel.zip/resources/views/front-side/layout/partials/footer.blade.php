<!-- Footer -->
    <footer class="footer text-right">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-center">
                    © {{ date('Y') }} SR TOURS & TRAVELS
                </div>
            </div>
        </div>
    </footer>
<!-- End Footer -->

  