  <!-- jQuery  -->
    <script src="{{asset('public/front-side/js/jquery.min.js')}}"></script>
    <script src="{{asset('public/front-side/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/front-side/js/detect.js')}}"></script>
    <script src="{{asset('public/front-side/js/fastclick.js')}}"></script>
    <script src="{{asset('public/front-side/js/jquery.blockUI.js')}}"></script>
    <script src="{{asset('public/front-side/js/waves.js')}}"></script>
    <script src="{{asset('public/front-side/js/jquery.slimscroll.js')}}"></script>
    <script src="{{asset('public/front-side/js/jquery.scrollTo.min.js')}}"></script>
    <script src="{{asset('public/front-side/js/select2.min.js')}}"></script>
    <script src="{{asset('public/front-side/plugins/switchery/switchery.min.js')}}"></script>
     <script src="{{asset('public/plugins/datatables/jquery.dataTables.min.js')}}"></script>
     <script src="{{asset('public/plugins/datatables/dataTables.bootstrap.js')}}"></script>
     <script src="{{asset('public/plugins/datatables/dataTables.buttons.min.js')}}"></script>
     <script src="{{asset('public/plugins/datatables/dataTables.fixedHeader.min.js')}}"></script>
    <script src="{{asset('public/front-side/js/jquery.core.js')}}"></script>
    <script src="{{asset('public/front-side/js/jquery.app.js')}}"></script>
      @stack('scripts')
