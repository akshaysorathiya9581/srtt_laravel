<footer class="footer text-right">
    {{ date('Y') }} © SR TOURS AND TRAVELS.
</footer>
