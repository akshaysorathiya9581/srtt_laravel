<?php $__env->startSection('content'); ?>
<!-- end row -->

   <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="btn-group pull-right">
                    <ol class="breadcrumb hide-phone p-0 m-0">
                        <li>
                            <a href="javascript:void(0);">Dashboard</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('paxprofile.index')); ?>">Pax Profile</a>
                        </li>
                        <li class="active">
                            Add New Pax Profile
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Add New Pax Profile</h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="card-box">
                <form action="<?php echo e(route('paxprofile.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="f_name">FIRST NAME<span class="text-danger">*</span></label>
                                <input type="text" name="f_name" placeholder="Enter First Name" class="form-control " value="<?php echo e(old('f_name')); ?>" autocomplete="off">
                                <?php if($errors->has('f_name')): ?> <p style="color:red;"><?php echo e($errors->first('f_name')); ?></p> <?php endif; ?>
                            </div>
                        </div> 
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="m_name">MIDDLE NAME</label>
                                <input type="text" name="m_name" placeholder="Enter Middle Name" class="form-control " value="<?php echo e(old('m_name')); ?>" autocomplete="off">
                                <?php if($errors->has('m_name')): ?> <p style="color:red;"><?php echo e($errors->first('m_name')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="l_name">LAST NAME<span class="text-danger">*</span></label>
                                <input type="text" name="l_name" placeholder="Enter Last Name" class="form-control " value="<?php echo e(old('l_name')); ?>" autocomplete="off">
                                <?php if($errors->has('l_name')): ?> <p style="color:red;"><?php echo e($errors->first('l_name')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="dob">DOB<span class="text-danger">*</span></label>
                                <input type="text" name="dob" placeholder="Enter Dob" class="form-control date" value="<?php echo e(old('dob')); ?>" autocomplete="off">
                                <?php if($errors->has('dob')): ?> <p style="color:red;"><?php echo e($errors->first('dob')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="place">PLACE<span class="text-danger">*</span></label>
                                <input type="text" name="place" placeholder="Enter Place" class="form-control " value="<?php echo e(old('place')); ?>" autocomplete="off">
                                <?php if($errors->has('place')): ?> <p style="color:red;"><?php echo e($errors->first('place')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="gender">GENDER<span class="text-danger">*</span></label><br>
                                <div class="radio radio-info radio-inline">
                                    <input type="radio" id="male" value="male" name="gender" checked="">
                                    <label for="male"> MALE </label>
                                </div>
                                <div class="radio radio-info radio-inline">
                                    <input type="radio" id="female" value="female" name="gender">
                                    <label for="female"> FEMALE </label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="email">EMAIL<span class="text-danger">*</span></label>
                                <input type="text" name="email" placeholder="Enter Email" class="form-control " value="<?php echo e(old('email')); ?>" autocomplete="off">
                                <?php if($errors->has('email')): ?> <p style="color:red;"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="con_coun_code">Country Code<span class="text-danger">*</span></label>
                                <select name="phone_coun_code" class="form-control  select2">
                                    <option value="">Select Country Code</option>
                                    <?php if(!(empty($countrys))): ?>
                                        <?php $__currentLoopData = $countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($country->phonecode); ?>"><?php echo e(strtoupper($country->name.'  +'.$country->phonecode)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                    <?php endif; ?>;
                                </select>
                                <?php if($errors->has('phone_coun_code')): ?> <p style="color:red;"><?php echo e($errors->first('phone_coun_code')); ?></p> <?php endif; ?>
                            </div>
                        </div> 
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="name">Phone number<span class="text-danger">*</span></label>
                                <input type="text" name="phone_number" placeholder="Enter Phone Number" class="form-control  " value="<?php echo e(old('phone_number')); ?>" autocomplete="off">
                                <?php if($errors->has('phone_number')): ?> <p style="color:red;"><?php echo e($errors->first('phone_number')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="con_coun_code">Country Code<span class="text-danger">*</span></label>
                                <select name="whatsapp_coun_code" class="form-control select2">
                                    <option value="">Select Country Code</option>
                                     <?php if(!(empty($countrys))): ?>
                                        <?php $__currentLoopData = $countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($country->phonecode); ?>"><?php echo e(strtoupper($country->name.'  +'.$country->phonecode)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                    <?php endif; ?>;
                                </select>
                                <?php if($errors->has('whatsapp_coun_code')): ?> <p style="color:red;"><?php echo e($errors->first('whatsapp_coun_code')); ?></p> <?php endif; ?>
                            </div>
                        </div> 
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="name">Whatsapp Number<span class="text-danger">*</span></label>
                                <input type="text" name="whatsapp_number" placeholder="Enter Whatsapp Number" class="form-control " value="<?php echo e(old('whatsapp_number')); ?>" autocomplete="off">
                                <?php if($errors->has('whatsapp_number')): ?> <p style="color:red;"><?php echo e($errors->first('whatsapp_number')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="meal_pre">MEAL PREFERENCE:<span class="text-danger">*</span></label>
                                <select name="meal_pre" class="form-control select2">
                                    <option value="">Select Service</option>
                                     <?php if(!(empty($mealPreferences))): ?>
                                        <?php $__currentLoopData = $mealPreferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mealPreference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($mealPreference['short_name']); ?>"><?php echo e($mealPreference['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                    <?php endif; ?>;
                                </select>
                                <?php if($errors->has('meal_pre')): ?> <p style="color:red;"><?php echo e($errors->first('meal_pre')); ?></p> <?php endif; ?>
                            </div>
                        </div>  
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="seat_pre">SEAT PREFERENCE:<span class="text-danger">*</span></label>
                                <select name="seat_pre" class="form-control select2">
                                    <option value="">Select Seat Preference:</option>
                                    <?php if(!(empty($seatPreferences))): ?>
                                        <?php $__currentLoopData = $seatPreferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seatPreference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($seatPreference['id']); ?>"><?php echo e($seatPreference['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                    <?php endif; ?>;
                                </select>
                                <?php if($errors->has('seat_pre')): ?> <p style="color:red;"><?php echo e($errors->first('seat_pre')); ?></p> <?php endif; ?>
                            </div>
                        </div> 
                    </div> 
                    <div class="form-group text-right m-b-0">
                        <button class="btn btn-primary waves-effect waves-light" type="submit">SAVE</button>
                        <button type="reset" class="btn btn-danger waves-effect m-l-5">Cancel</button>
                    </div>
                </form>
            </div> <!-- end card-box -->
        </div><!-- end col-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        jQuery(document).ready(function () {
            $(".select2").select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('front-side.layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/front-side/paxprofile/create.blade.php ENDPATH**/ ?>