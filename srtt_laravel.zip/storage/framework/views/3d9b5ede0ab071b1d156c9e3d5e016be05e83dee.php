<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="btn-group pull-right">
                <ol class="breadcrumb hide-phone p-0 m-0">
                    <li>
                        <a href="<?php echo e(route('paxprofile.index')); ?>">Pax Profile Management</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    </li>
                </ol>
            </div>
            <h4 class="page-title">
                <a href="<?php echo e(route('paxprofile.index')); ?>" class="btn btn-danger waves-effect waves-light m-b-5 pull-left"> <i class="mdi mdi-reply-all"></i> <span> BACK</span></a>
            </h4>
        </div>
    </div>
</div>
<!-- end row -->

<div class="row">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('paxprofile.create')); ?>" class="btn btn-inverse waves-effect waves-light m-b-5 pull-right"> <i class="mdi mdi-plus"></i> <span> ADD NEW</span></a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                            <i class="mdi mdi-check-all"></i>
                            <strong>SUCCESS !</strong> <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <table id="datatable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>REFERENCE CODE</th>
                        <th>NAME</th>
                        <th>PLACE</th>
                        <th>DOB</th>
                        <th>CREATED DATE</th>
                        <th>UPDATED DATE</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                      
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        var table =$('#datatable').DataTable({
            "processing": true,
            "serverSide": true,
            "bDestroy": true,
            "ajax":{
                "url": "<?php echo e(route('paxprofile.index')); ?>",
                "dataType": "json",
                'data': {"_token": "<?php echo e(csrf_token()); ?>"},
            },
            "columns": [
                { "data": "id" },
                { "data": "reference_code" },
                { "data": "name" },
                { "data": "place" },
                { "data": "dob" },
                { "data": "created_at" },
                { "data": "updated_at" },
                { "data": "action" }
            ]	 
        });

        $(document).on('click','.delete-btn',function(){
            var $this = $(this);
            var id = $this.data('id');
            $this.find('form').submit();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front-side.layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/front-side/paxprofile/index.blade.php ENDPATH**/ ?>