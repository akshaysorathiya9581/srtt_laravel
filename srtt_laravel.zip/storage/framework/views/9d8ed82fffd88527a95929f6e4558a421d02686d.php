<!DOCTYPE html>
<html lang="en">
	 <head>
	   <?php echo $__env->make('admin-side.layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	 </head>
	 <body class="fixed-left">
		<div class="wrapper">
		<?php echo $__env->make('admin-side.layout.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('admin-side.layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('admin-side.layout.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content-page"><!-- Start content -->
                <div class="content">
                    <div class="container">
						<?php echo $__env->yieldContent('content'); ?>
				 	</div> <!-- container -->
                </div> <!-- content -->
				<?php echo $__env->make('admin-side.layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</div><!-- end wrapper -->
		<?php echo $__env->make('admin-side.layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</body>
</html>
<?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/layout/mainlayout.blade.php ENDPATH**/ ?>