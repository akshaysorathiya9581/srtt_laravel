  <!-- jQuery  -->
    <script src="<?php echo e(asset('public/front-side/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/detect.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/fastclick.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/jquery.blockUI.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/waves.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/jquery.scrollTo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/plugins/switchery/switchery.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/dataTables.bootstrap.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/jquery.core.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front-side/js/jquery.app.js')); ?>"></script>
      <?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/front-side/layout/partials/footer-scripts.blade.php ENDPATH**/ ?>