<?php $__env->startSection('content'); ?>
<!-- end row -->
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">Edit Permission</h4>
                <ol class="breadcrumb p-0 m-0">
                    <li class="active">
                        <a href="<?php echo e(route('permissions.index')); ?>">BACK</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD</a>
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
    </div><!-- end row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="card-box">
                <form action="<?php echo e(route('permissions.update',$data['id'])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
                    <div class="form-group">
                        <label for="name">NAME<span class="text-danger">*</span></label>
                        <input type="text" name="name" placeholder="ENTER PERMISSION NAME" class="form-control input-sm" value="<?php echo e($data['name']); ?>" autocomplete="off">
                        <?php if($errors->has('name')): ?> <p style="color:red;"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
                    </div>

                    <div class="form-group text-right m-b-0">
                        <button class="btn btn-primary waves-effect waves-light" type="submit">SAVE</button>
                        <button type="reset" class="btn btn-default waves-effect m-l-5">Cancel</button>
                    </div>
                </form>
            </div> <!-- end card-box -->
        </div><!-- end col-->
    </div>
<!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-side.layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/permission/edit.blade.php ENDPATH**/ ?>