   <script>
    var resizefunc = [];

    </script>
  <!-- jQuery  -->
    <script src="<?php echo e(asset('public/admin-side/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/detect.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/fastclick.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/jquery.blockUI.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/waves.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/jquery.scrollTo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/plugins/switchery/switchery.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/dataTables.bootstrap.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/plugins/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/jquery.core.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin-side/js/jquery.app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/layout/partials/footer-scripts.blade.php ENDPATH**/ ?>