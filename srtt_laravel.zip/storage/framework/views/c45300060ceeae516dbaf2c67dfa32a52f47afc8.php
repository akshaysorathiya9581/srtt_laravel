<?php $__env->startSection('content'); ?>
<!-- end row -->
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">EDIT NEW USER </h4>
                <ol class="breadcrumb p-0 m-0">
                    <li class="active">
                        <a href="<?php echo e(route('users.index')); ?>">BACK</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD</a>
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
    </div><!-- end row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="card-box">
                <form action="<?php echo e(route('users.update',$user->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="userName">NAME<span class="text-danger">*</span></label>
                        <input type="text" name="name" placeholder="ENTER USERNAME" class="form-control input-sm" value="<?php echo e($user->name); ?>">
                        <?php if($errors->has('name')): ?> <p style="color:red;"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="userName">EMAIL<span class="text-danger">*</span></label>
                        <input type="text" name="email" placeholder="ENTER EMAIL" class="form-control input-sm" value="<?php echo e($user->email); ?>">
                        <?php if($errors->has('email')): ?> <p style="color:red;"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="userName">PASSWORD<span class="text-danger">*</span></label>
                        <input type="text" name="password" placeholder="ENTER PASSWORD" class="form-control input-sm">
                        <?php if($errors->has('password')): ?> <p style="color:red;"><?php echo e($errors->first('password')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="userName">CONFIRM PASSWORD<span class="text-danger">*</span></label>
                        <input type="text" name="confirm-password" placeholder="ENTER PASSWORD" class="form-control input-sm">
                        <?php if($errors->has('password')): ?> <p style="color:red;"><?php echo e($errors->first('password')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">ROLES<span class="text-danger">*</span></label>
                        <select name="roles" class="form-control input-sm">
                            <option value="">SELECT ROLES</option>
                            <?php if(!(empty($roles))): ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role['id']); ?>" <?php if(old('roles') == $user->role): ?> selected <?php endif; ?>><?php echo e($role['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('roles')): ?> <p style="color:red;"><?php echo e($errors->first('roles')); ?></p> <?php endif; ?>
                    </div>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $checked = in_array($permission['id'], $getApplyPermission) ? 'checked' : '';
                    ?>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="permission[]" value="<?php echo e($permission['id']); ?>" <?php echo e($checked); ?>> <?php echo e($permission['name']); ?> 
                                </label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group text-right m-b-0">
                        <button class="btn btn-primary waves-effect waves-light" type="submit">SAVE</button>
                        <button type="reset" class="btn btn-default waves-effect m-l-5">Cancel</button>
                    </div>
                </form>
            </div> <!-- end card-box -->
        </div><!-- end col-->
    </div>
<!-- end row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <script>
        $(document).on('change', 'select[name="roles"]', function(event) {
            event.preventDefault();
            var $this = $(this);
            var id = $this.val();
            $.ajax({
                method: "POST",
                url: "<?php echo e(route('getRolePermission')); ?>",
                data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                "id": id
                }
                }).done(function( data ) {

                var html = '';
                $.each(data.data.permissions,function(index, el) {
                    html +='<div class="col-md-3">';
                         html += '<div class="form-group">';
                            html +='<label class="checkbox-inline">';
                                 html +='<input type="checkbox" name="permission[]" value="'+el.id+'">'+el.name+'</label>';
                         html +='</div>';
                     html +='</div>'
                });
                $('.rolePermission').html(html);
            });
        });
        
        $('select[name="roles"]').val('<?php echo $user["roles"]; ?>').trigger('change');
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin-side.layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/users/edit.blade.php ENDPATH**/ ?>