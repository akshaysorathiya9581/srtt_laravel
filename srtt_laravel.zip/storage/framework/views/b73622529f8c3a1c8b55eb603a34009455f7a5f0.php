<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-xs-12">
		<div class="page-title-box">
            <h4 class="page-title">Role Management </h4>
            <ol class="breadcrumb p-0 m-0">
                <li class="active">
                    <a href="<?php echo e(route('roles.index')); ?>">BACK</a>
                </li>
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD</a>
                </li>
            </ol>
            <div class="clearfix"></div>
        </div>
	</div>
</div>
<!-- end row -->


<div class="row">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
             <div class="col-md-12">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <i class="mdi mdi-check-all"></i>
                        <strong>SUCCESS !</strong> <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-inverse waves-effect waves-light m-b-5 pull-right"> <i class="mdi mdi-plus"></i> <span> ADD NEW</span> </a>
            </div>

            <table id="datatable" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>NO</th>
                    <th>NAME</th>
                    <th>CREATED DATE</th>
                    <th>UPDATED DATE</th>
                    <th>ACTION</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('public/admin-side/js/modules/airlinelistController.js')); ?>"></script>
    <script>
        var table =$('#datatable').DataTable({
            "processing": true,
            "serverSide": true,
            "bDestroy": true,
            "ajax":{
                "url": "<?php echo e(route('roles.index')); ?>",
                "dataType": "json",
                'data': {"_token": "<?php echo e(csrf_token()); ?>"},
            },
            "columns": [
                { "data": "id" },
                { "data": "name" },
                { "data": "created_at" },
                { "data": "updated_at" },
                { "data": "action" }
            ]	 
        });

        $(document).on('click','.delete-btn',function(){
            var $this = $(this);
            var id = $this.data('id');
            $this.find('form').submit();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-side.layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/roles/index.blade.php ENDPATH**/ ?>