<footer class="footer text-right">
    <?php echo e(date('Y')); ?> © SR TOURS AND TRAVELS.
</footer>
<?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/layout/partials/footer.blade.php ENDPATH**/ ?>