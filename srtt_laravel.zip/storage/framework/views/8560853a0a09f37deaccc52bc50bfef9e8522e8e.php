<?php $__env->startSection('content'); ?>
<!-- end row -->
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">AIRLINE-LIST </h4>
                <ol class="breadcrumb p-0 m-0">
                    <li class="active">
                        <a href="<?php echo e(route('airlienList.index')); ?>">BACK</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD</a>
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
    </div><!-- end row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="card-box">
                <form action="<?php echo e(route('airlienList.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="userName">NAME<span class="text-danger">*</span></label>
                        <input type="text" name="name" placeholder="ENTER AIRLINE NAME" class="form-control input-sm" value="<?php echo e(old('name')); ?>">
                        <?php if($errors->has('name')): ?> <p style="color:red;"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="emailAddress">MEMBERSHIP PLAN<span class="text-danger">*</span></label>
                        <select name="membership_plan" class="form-control input-sm">
                            <option value="">SELECT MEMBERSHIP PLAN</option>
                            <option value="YES" <?php if(old('membership_plan') == 'YES'): ?> selected <?php endif; ?>>YES</option>
                            <option value="NO" <?php if(old('membership_plan') == 'NO'): ?> selected <?php endif; ?>>NO</option>
                        </select>
                        <?php if($errors->has('membership_plan')): ?> <p style="color:red;"><?php echo e($errors->first('membership_plan')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">AIRLINE GROUP<span class="text-danger">*</span></label>
                        <select name="airline_group" class="form-control input-sm">
                            <option value="">SELECT AIRLINE GROUP</option>
                            <?php if(!(empty($airlineGroups))): ?>
                                <?php $__currentLoopData = $airlineGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airlineGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($airlineGroup['id']); ?>" <?php if(old('airline_group') == $airlineGroup['id']): ?> selected <?php endif; ?>><?php echo e($airlineGroup['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('airline_group')): ?> <p style="color:red;"><?php echo e($errors->first('airline_group')); ?></p> <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">AIRLINE GST<span class="text-danger">*</span></label>
                        <select name="airline_gst" class="form-control input-sm" value="<?php echo e(old('airline_gst')); ?>">
                            <option value="">SELECT AIRLINE GST</option>
                            <option value="0" <?php if(old('airline_gst') == '0'): ?> selected <?php endif; ?>>FROM AIRLINE</option>
                            <option value="1" <?php if(old('airline_gst') == '1'): ?> selected <?php endif; ?>>FROM WEBSITE</option>
                        </select>
                        <?php if($errors->has('airline_gst')): ?> <p style="color:red;"><?php echo e($errors->first('airline_gst')); ?></p> <?php endif; ?>
                    </div>
                    <div class="airline-gst"></div>
                    <div class="form-group">
                        <label for="pass1">LOGO<span class="text-danger">*</span></label>
                        <input  type="file" class="form-control input-sm" name="logo">
                        <?php if($errors->has('logo')): ?> <p style="color:red;"><?php echo e($errors->first('logo')); ?></p> <?php endif; ?>
                    </div>
                   
                    <div class="form-group text-right m-b-0">
                        <button class="btn btn-primary waves-effect waves-light" type="submit">SAVE</button>
                        <button type="reset" class="btn btn-default waves-effect m-l-5">Cancel</button>
                    </div>
                </form>
            </div> <!-- end card-box -->
        </div><!-- end col-->
    </div>
<!-- end row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('public/admin-side/js/modules/airlinelistController.js')); ?>"></script>
    <script>
        $(document ).ready(function() {
            $(document).on('change', 'select[name="airline_gst"]', function(event) {
                event.preventDefault();
                var $this = $(this);
                var val = $this.val();
                var html = '';
                if(val == '0') {
                    html += '<div class="form-group">';
                            html +='<label class="control-label mb-10 text-left">EMAIL<span class="text-danger">*</span></label>';
                            html += '<input type="text" name="email" class="form-control input-sm" placeholder="ENTER EMAIL" autocomplete="off" value="<?php echo e(old('email')); ?>">';
                            html += '<?php if($errors->has('email')): ?> <p style="color:red;"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>';
                        html += '</div>';
                    html += '</div>';
                    html += '<div class="form-group">';
                            html +='<label class="control-label mb-10 text-left">PHONE NUMBER<span class="text-danger">*</span></label>';
                            html += '<input type="text" name="phone_number" class="form-control input-sm" placeholder="ENTER PHONE NUMBER" autocomplete="off" value="<?php echo e(old('phone_number')); ?>">';
                            html += '<?php if($errors->has('phone_number')): ?> <p style="color:red;"><?php echo e($errors->first('phone_number')); ?></p> <?php endif; ?>';
                        html += '</div>';
                    html += '</div>'; 
                    html += '<div class="form-group">';
                            html += '<label class="control-label mb-10 text-left">CONTACT PERSON<span class="text-danger">*</span></label>';
                            html += '<input type="text" name="contact_person" class="form-control input-sm" placeholder="ENTER CONTACT PERSON" autocomplete="off" value="<?php echo e(old('contact_person')); ?>">';
                            html += '<?php if($errors->has('contact_person')): ?> <p style="color:red;"><?php echo e($errors->first('contact_person')); ?></p> <?php endif; ?>';
                        html += '</div>';
                    html += '</div>';
                } else {
                    html += '<div class="form-group">';
                            html +='<label class="control-label mb-10 text-left">EMAIL<span class="text-danger">*</span></label>';
                            html += '<input type="text" name="url" class="form-control input-sm" placeholder="ENTER AIRLINE URL" autocomplete="off" value="<?php echo e(old('url')); ?>">';
                            html += '<?php if($errors->has('url')): ?> <p style="color:red;"><?php echo e($errors->first('url')); ?></p> <?php endif; ?>';
                        html += '</div>';
                    html += '</div>';
                }
                
                $('.airline-gst').html(html);
            });
            $('select[name="airline_gst"]').val('<?php echo old("airline_gst"); ?>').trigger('change');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-side.layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/admin-side/airline-list/create.blade.php ENDPATH**/ ?>