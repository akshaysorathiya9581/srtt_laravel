<!-- Footer -->
    <footer class="footer text-right">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-center">
                    © <?php echo e(date('Y')); ?> SR TOURS & TRAVELS
                </div>
            </div>
        </div>
    </footer>
<!-- End Footer -->

  <?php /**PATH F:\xampp\htdocs\srtt_laravel\resources\views/front-side/layout/partials/footer.blade.php ENDPATH**/ ?>