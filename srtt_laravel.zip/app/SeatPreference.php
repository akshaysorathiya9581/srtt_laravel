<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SeatPreference extends Model
{
    //
}
